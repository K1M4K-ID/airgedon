__version__ = '1.5.0'
__description__ = 'Monitors, analyzes and limits the bandwidth of devices on the local network'